# Recorded Kresling geometry search

The geometric search helped narrow down plausible geometries. The website replays 11 adaptive candidates followed by continuous-sheet, full-facet and one-piece revisions.

To reproduce in a fresh folder with Python 3.12, install requirements.txt and run:

    python models/run_kresling_search.py --max-candidates 24
    python models/run_no_holes_search.py
    python models/run_full_facet_search.py
    python models/run_one_piece_check.py

Results are written to output/. Preserve the archived records in a separate copy before re-running.

Model: bar-and-hinge elasticity, assumed crease properties, frictionless contact and ideal bonded seams. Full-facet overlaps use equivalent laminate stiffness. Contact exclusions and independent intersection checks are implemented in kresling_contact_search.py and contact_validation.py. The calculations supported geometry selection; the physical specimens were assessed using release videos.
