# Recorded Kresling geometry search

The website replays saved candidate results; it does not execute an elastic solver in the browser.
The adaptive run tested 11 candidates. Later no-hole, full-facet and one-piece stages are distinct design revisions, not one continuous optimizer run.

To reproduce in a fresh folder with Python 3.12, install requirements.txt and run:

    python models/run_kresling_search.py --max-candidates 24
    python models/run_no_holes_search.py
    python models/run_full_facet_search.py
    python models/run_one_piece_check.py

These scripts write results under output/ and may take several minutes or longer. Make a copy of the archived output first if preserving it. The scripts use assumed material constants and model contact; they do not certify physical bistability. Minor numerical differences can arise between library versions and platforms.
