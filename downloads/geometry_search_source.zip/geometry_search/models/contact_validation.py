"""Triangle intersection checks including coplanar overlaps."""
import numpy as np
from shapely.geometry import Polygon

def all_intersections(vertices,faces,owners,coplanar=True,bonded_pairs=None):
    x=np.asarray(vertices,dtype=float);f=np.asarray(faces);o=np.asarray(owners);t=x[f]
    i,j=np.triu_indices(len(f),1)
    bonded_pairs=[(12,10),(13,10)] if bonded_pairs is None else bonded_pairs
    bonded=np.zeros(len(i),dtype=bool)
    for tab,receiver in bonded_pairs:
        bonded|=((o[i]==tab)&(o[j]==receiver))|((o[j]==tab)&(o[i]==receiver))
    active=(~bonded)&np.all(t[i].max(1)>=t[j].min(1)-1e-9,axis=1)&np.all(t[j].max(1)>=t[i].min(1)-1e-9,axis=1)
    i,j=i[active],j[active];a,b=t[i],t[j];hits=np.zeros(len(i),bool)
    shared=np.sum(np.any(f[i,:,None]==f[j,None,:],axis=2),axis=1)
    for p,q in [(a,b),(b,a)]:
        # Extended precision limits roundoff near coplanar shared vertices.

        p=p.astype(np.longdouble);q=q.astype(np.longdouble)
        e1=q[:,1]-q[:,0];e2=q[:,2]-q[:,0]
        for k in range(3):
            start=p[:,k];direction=p[:,(k+1)%3]-start
            cr=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,cr)
            # Relative tolerances preserve behavior under rotation and rescaling.

            scale=np.linalg.norm(e1,axis=1)*np.linalg.norm(e2,axis=1)*np.linalg.norm(direction,axis=1)
            ok=np.abs(det)>1e-10*scale;inv=np.divide(1,det,out=np.zeros_like(det),where=ok)
            v0=start-q[:,0];u=inv*np.einsum('ij,ij->i',v0,cr);v1=np.cross(v0,e1)
            v=inv*np.einsum('ij,ij->i',direction,v1);along=inv*np.einsum('ij,ij->i',e2,v1)
            eps=1e-7
            hits|=ok&(u>eps)&(v>eps)&(u+v<1-eps)&(along>eps)&(along<1-eps)

    hits[shared>=2]=False
    if coplanar:
        normals=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]);lengths=np.linalg.norm(normals,axis=1)
        normals=normals/np.maximum(lengths[:,None],1e-30)
        distance=np.max(np.abs(np.einsum('ijk,ik->ij',b-a[:,0,None,:],normals)),axis=1)
        # Coplanar classification overrides ill-conditioned segment intersections.

        for k in np.flatnonzero(distance<1e-8):
            axes=[z for z in range(3) if z!=np.argmax(np.abs(normals[k]))]
            hits[k]=Polygon(a[k][:,axes]).intersection(Polygon(b[k][:,axes])).area>1e-8
    return np.c_[i[hits],j[hits]].tolist()

def test():
    f=[[0,1,2],[3,4,5]]
    first=[[0,0,0],[2,0,0],[0,2,0]]
    assert all_intersections(first+[[.5,.5,-1],[.5,.5,1],[1,.5,0]],f,[0,1])
    assert not all_intersections(first+[[.5,.5,1],[1,.5,1],[.5,1,1]],f,[0,1])
    assert all_intersections(first+[[.2,.2,0],[.4,.2,0],[.2,.4,0]],f,[0,1])
    assert not all_intersections(first+[[2,0,0],[2,2,0],[0,2,0]],f,[0,1])

    rng=np.random.default_rng(72)
    base=np.array(first+[[2,0,0],[2,2,0],[0,2,0]],float)
    for scale in [.001,1.,35.,1000.]:
        rotation=np.linalg.qr(rng.normal(size=(3,3)))[0]
        assert not all_intersections(scale*base@rotation,f,[0,0])
    assert not all_intersections(first+[[.2,.2,0],[.4,.2,0],[.2,.4,0]],f,[12,10])

    fan=[[35.,0.,0.],[33.20677074850284,2.7212911583239237,3.7572308583507064],
         [25.306523770724787,-1.4336067645066668,9.90105692600525],
         [27.879773529749787,14.685922837527515,17.420689395414744],
         [27.069143516944614,16.50662765849124,19.499911345956534]]
    assert not all_intersections(fan,[[0,1,2],[3,4,2]],[10,10])
    print('Independent intersection tests passed: crossing, separate, coplanar overlap, shared boundary, adhesive exclusion.')
if __name__=='__main__':test()
