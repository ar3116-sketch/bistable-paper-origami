"""Automatic constrained Kresling search; exploratory mechanics, not a material certification.

IPC Toolkit supplies barriers and CCD. JAX supplies exact elastic derivatives.
The minimizer uses LINEAR nodal coordinates so IPC's CCD assumption holds.
Top-cap planarity/centering are exact; very stiff bars approximate in-plane cap
rigidity. Collision exclusions are documented and independently screened.
"""
from pathlib import Path
import argparse, json, math, time, sys
import numpy as np
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import ipctk as ipc
ipc.set_num_threads(1)
from scipy.linalg import solve
from shapely.geometry import Polygon,LineString
from kresling_v2_simulation import mesh
from check_v2_intersections import intersections
from contact_validation import all_intersections

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/kresling_search';OUT.mkdir(exist_ok=True)

def specification(lam=.70,slit=.30,width=5.,tab_centre=.67,side=35.,slot_width=.8,seam_gap=.6):
    al=lam*np.pi/3;v=2*side*np.cos(np.pi/3-al);s=v*np.cos(al)-side;rise=v*np.sin(al)
    mountain=np.hypot(s,rise);q=np.radians(120*(1-lam));z=np.sqrt(mountain**2-2*side**2*(1-np.cos(q)))
    def tab(lo,hi,w):return [[s*lo,rise*lo],[s*lo-w,rise*lo],[s*hi-w*.65,rise*hi],[s*hi,rise*hi]]
    tabs={'A':tab(tab_centre-.07,tab_centre+.07,width),'B':tab(.12,.32,width)}
    receiver=Polygon([[5*side,0],[6*side,0],[6*side+s,rise]])
    clear=[]
    for pts in tabs.values():
        shape=Polygon(np.array(pts)+[6*side,0])
        if not receiver.buffer(1e-8).covers(shape):raise ValueError('tab leaves its receiving facet')
        if Polygon(pts).buffer(-1.,join_style=2).area<3.:raise ValueError('too little usable adhesive area')
        clear.append(shape.distance(LineString([[5*side,0],[6*side+s,rise]])))
    if min(clear)<2:raise ValueError('tab too close to valley')
    if 6*side+s+width>254:raise ValueError('Letter width exceeded')
    return dict(N=6,side_and_radius_mm=side,**{'lambda':float(lam)},flat_shift_mm=float(s),flat_rise_mm=float(rise),
      valley_mm=float(v),mountain_mm=float(mountain),ideal_twist_open_deg=float(np.degrees(q)),ideal_extended_height_mm=float(z),
      relief_cut_fraction_of_mountain=float(slit),tabs=tabs,tab_valley_clearance_mm=min(clear),tab_width_mm=float(width),tab_centre=float(tab_centre),
      slot_width_mm=slot_width,seam_gap_mm=seam_gap)

def angles(x,hinges):
    a,b,c,d=[x[hinges[:,i]] for i in range(4)];e=b-a
    n1=jnp.cross(e,c-a);n2=jnp.cross(-e,d-b)
    unit=lambda z:z/jnp.sqrt(jnp.sum(z*z,axis=1,keepdims=True))
    n1,n2,axis=unit(n1),unit(n2),unit(e)
    return jnp.arctan2(jnp.sum(jnp.cross(n1,n2)*axis,axis=1),jnp.sum(n1*n2,axis=1))

class ContactModel:
    def __init__(self,spec,kbend=1e-4,ratio=100,dhat_mm=.5,thickness_mm=None,audit_steps=False):
        if thickness_mm is None:thickness_mm=spec.get('contact_thickness_mm',.2)
        self.spec=spec;self.a=spec['side_and_radius_mm'];self.m=mesh(spec)
        m=self.m;self.x0=m['vertices'];self.faces=m['faces'];self.owners=np.array(m['owners']);n=len(self.x0)
        self.edges=m['edges'];self.hinges=m['hinges'];self.free=m['free'];self.kbend=kbend;self.ratio=ratio
        self.bonded_pairs=m['bonded_owner_pairs']
        # Linear independent coordinates: five top xy positions, the sixth
        # balances their sum; all other free mesh nodes; final scalar = H.
        nd=10+3*len(self.free)+1;T=np.zeros((12+len(self.free),3,nd));C=np.zeros((12+len(self.free),3))
        C[:6]=self.x0[:6]
        for i in range(5):
            T[6+i,0,2*i]=1;T[6+i,1,2*i+1]=1
            T[11,0,2*i]=-1;T[11,1,2*i+1]=-1
        T[6:12,2,-1]=1
        for j in range(len(self.free)):
            for k in range(3):T[12+j,k,10+3*j+k]=1
        self.T=np.einsum('ij,jkl->ikl',m['transform'],T).reshape(n*3,nd)
        self.C=(m['transform']@C).ravel()
        self.d0=np.r_[self.x0[6:11,:2].ravel(),self.x0[self.free].ravel(),spec['ideal_extended_height_mm']/self.a]
        assert np.max(np.abs(self.coords(self.d0)-self.x0))<1e-12
        edge=jnp.array(self.edges);hinge=jnp.array(self.hinges)
        l0=jnp.linalg.norm(self.x0[self.edges[:,1]]-self.x0[self.edges[:,0]],axis=1)
        hl0=jnp.linalg.norm(self.x0[self.hinges[:,1]]-self.x0[self.hinges[:,0]],axis=1)
        # A full-facet overlap is represented as one perfectly bonded laminate
        # surface. Its in-plane stiffness scales with thickness; facet bending
        # scales with thickness cubed. Creases remain single-sheet hinges.
        laminated=set(spec.get('laminated_facet_owners',[]))
        incident={tuple(e):[] for e in self.edges}
        for tri,owner in zip(self.faces,self.owners):
            for aa,bb in zip(tri,np.roll(tri,-1)):
                incident[tuple(sorted((aa,bb)))].append(int(owner))
        axial_factor=spec.get('laminate_axial_multiplier',2.)
        bend_factor=spec.get('laminate_bend_multiplier',8.)
        ew=np.array([np.mean([axial_factor if o in laminated else 1. for o in incident[tuple(e)]]) for e in self.edges])
        kw=np.array([bend_factor if typ=='bend' and incident[tuple(sorted(h[:2]))][0] in laminated else 1.
                     for h,typ in zip(self.hinges,m['types'])])
        self.edge_stiffness_multipliers=ew;self.hinge_stiffness_multipliers=kw
        theta0=angles(jnp.array(self.x0),hinge);k=jnp.array(np.where(np.array(m['types'])=='bend',kbend,kbend/ratio)*kw)
        edge_weights=jnp.array(ew)
        caps=np.array([(i,j) for i in range(6,12) for j in range(i+1,12)])
        cap_l0=jnp.linalg.norm(self.x0[caps[:,1]]-self.x0[caps[:,0]],axis=1)
        P=jnp.array(self.T);c0=jnp.array(self.C)
        def elastic(d):
            x=(c0+P@d).reshape(n,3)
            lens=jnp.linalg.norm(x[edge[:,1]]-x[edge[:,0]],axis=1)
            theta=angles(x,hinge);diff=jnp.arctan2(jnp.sin(theta-theta0),jnp.cos(theta-theta0))
            cl=jnp.linalg.norm(x[caps[:,1]]-x[caps[:,0]],axis=1)
            return .5*jnp.sum(edge_weights*l0*(lens/l0-1)**2)+.5*jnp.sum(k*hl0*diff**2)+50*jnp.sum((cl-cap_l0)**2)
        self.ef=jax.jit(jax.value_and_grad(elastic));self.eh=jax.jit(jax.hessian(elastic))
        self.l0=np.array(l0);self.caps=caps;self.cap_l0=np.array(cap_l0)
        self.cm=ipc.CollisionMesh(self.x0,self.edges,self.faces)
        # Coincident slit lips and ideal adhesive bonds are connected material,
        # not two independent surfaces. Exclude only their vertex-pair masks.
        allowed=np.ones((n,n),bool)
        coincident=np.linalg.norm(self.x0[:,None]-self.x0[None,:],axis=2)<1e-8
        allowed[coincident]=False
        # A slit has initially coincident lips. IPC's primitive filter uses
        # OR across vertex pairs; suppress the incident one-ring neighborhoods
        # to avoid an infinite barrier at these intentional initial contacts.
        # The independent full-facet intersection screen still checks them.
        neighbors=[set([i]) for i in range(n)]
        for tri in self.faces:
            for i in tri:neighbors[i].update(tri)
        for i,j in zip(*np.where(np.triu(coincident,1))):
            aa=list(neighbors[i]);bb=list(neighbors[j])
            allowed[np.ix_(aa,bb)]=False;allowed[np.ix_(bb,aa)]=False
        for tab_owner,receiver_owner in self.bonded_pairs:
            receiver=np.unique(self.faces[self.owners==receiver_owner]);tabs=np.unique(self.faces[self.owners==tab_owner])
            allowed[np.ix_(tabs,receiver)]=False;allowed[np.ix_(receiver,tabs)]=False
        self.allowed=allowed
        self.cm.can_collide=ipc.make_sparse_filter({(int(i),int(j)):False for i,j in zip(*np.where(np.triu(~allowed,1)))},True)
        self.dhat=dhat_mm/self.a;self.dmin=thickness_mm/self.a;self.barrier=ipc.BarrierPotential(self.dhat,1e3)
        self.collisions=ipc.NormalCollisions()
        self.evaluations=0
        self.audit_steps=audit_steps;self.audited_segments=0
    def coords(self,d):return (self.C+self.T@d).reshape(-1,3)
    def objective(self,d,hessian=False):
        x=self.coords(d);self.collisions.build(self.cm,x,self.dhat,self.dmin)
        b=self.barrier(self.collisions,self.cm,x)
        if not np.isfinite(b):return np.inf,np.zeros(len(d)),None
        e,g=self.ef(d);g=np.array(g)+self.T.T@self.barrier.gradient(self.collisions,self.cm,x)
        H=None
        if hessian:
            H=np.array(self.eh(d))+self.T.T@self.barrier.hessian(self.collisions,self.cm,x).toarray()@self.T
        self.evaluations+=1
        return float(e)+float(b),g,H
    def metrics(self,d):
        x=self.coords(d);pairs=all_intersections(x*self.a,self.faces,self.owners,bonded_pairs=self.bonded_pairs)
        return dict(height_mm=float(d[-1]*self.a),strain=float(np.max(np.abs(np.linalg.norm(x[self.edges[:,1]]-x[self.edges[:,0]],axis=1)/self.l0-1))),
            cap_edge_error_mm=float(np.max(np.abs(np.linalg.norm(x[self.caps[:,1]]-x[self.caps[:,0]],axis=1)-self.cap_l0))*self.a),
            crossing_pairs=pairs,coordinates_mm=(x*self.a).tolist())
    def relax(self,d,hold_h=True,maxiter=180,gtol=2e-7):
        d=d.copy();ids=np.arange(len(d)-int(hold_h));last_step=0
        for it in range(maxiter):
            E,g,H=self.objective(d,True);gg=g[ids];grad=float(np.max(np.abs(gg)))
            if not np.isfinite(E):return d,dict(ok=False,reason='infeasible barrier',iteration=it)
            if grad<gtol:return d,dict(ok=True,energy=E,max_gradient=grad,iterations=it)
            HH=H[np.ix_(ids,ids)];HH=(HH+HH.T)/2
            eigen=np.linalg.eigvalsh(HH)[0]
            # Modified Newton matrix: a descent direction, no acceptance by
            # optimizer success flag alone. Armijo and CCD gate EVERY step.
            HH+=np.eye(len(ids))*max(1e-7,1e-6-eigen)
            direction=np.zeros(len(d));direction[ids]=solve(HH,-gg,assume_a='pos')
            maxmove=np.max(np.linalg.norm((self.T@direction).reshape(-1,3),axis=1))
            if maxmove>.1:direction*=.1/maxmove
            x=self.coords(d);xx=self.coords(d+direction)
            alpha=float(ipc.compute_collision_free_stepsize(self.cm,x,xx,self.dmin))
            if alpha<1:alpha*=.9
            descent=float(g@direction)
            accepted=False
            for ls in range(30):
                trial=d+alpha*direction
                if trial[-1]<.008 or trial[-1]>2:alpha*=.5;continue
                Et,_,_=self.objective(trial)
                if np.isfinite(Et) and Et<=E+1e-4*alpha*descent:
                    if self.audit_steps:
                        for fraction in [.25,.5,.75,1.]:
                            if all_intersections(self.coords(d+fraction*alpha*direction)*self.a,self.faces,self.owners,bonded_pairs=self.bonded_pairs):
                                return d,dict(ok=False,reason='independent segment intersection check',max_gradient=grad,iterations=it)
                        self.audited_segments+=1
                    d=trial;accepted=True;last_step=alpha;break
                alpha*=.5
            if not accepted:return d,dict(ok=False,reason='line search or contact blocked',max_gradient=grad,iterations=it,step=alpha)
        return d,dict(ok=False,reason='iteration limit',max_gradient=grad,iterations=maxiter,step=last_step)

def trial(spec,steps=20,kbend=1e-4,ratio=100,verbose=False,thickness_mm=None,audit_steps=False,max_strain=.01,dhat_mm=.5,compressed_fraction=.15):
    start=time.time();m=ContactModel(spec,kbend=kbend,ratio=ratio,thickness_mm=thickness_mm,audit_steps=audit_steps,dhat_mm=dhat_mm);d=m.d0.copy();records=[];initial=m.objective(d)
    if verbose:print('INITIAL',float(initial[0]),'crossings',len(m.metrics(d)['crossing_pairs']),flush=True)
    last_h=d[-1]
    for i,h in enumerate(np.linspace(d[-1],max(.07,compressed_fraction*d[-1]),steps)):
        # Loading move is itself collision-checked, not just equilibrium states.
        old=d.copy();d[-1]=h
        # Move free nodes affinely along z; the ring remains planar.
        for j in range(len(m.free)):d[10+3*j+2]*=h/last_h
        alpha=float(ipc.compute_collision_free_stepsize(m.cm,m.coords(old),m.coords(d),m.dmin))
        if alpha<1:
            return dict(passed=False,reason='loading increment blocked',progress=i/(steps-1),records=records,spec=spec,elapsed=time.time()-start)
        if audit_steps:
            for f in [.25,.5,.75,1.]:
                if all_intersections(m.coords(old+f*(d-old))*m.a,m.faces,m.owners,bonded_pairs=m.bonded_pairs):
                    return dict(passed=False,reason='loading interpolation crossing',progress=i/(steps-1),records=records,spec=spec,elapsed=time.time()-start)
        d,con=m.relax(d);met=m.metrics(d);rec=dict(**con,**met);records.append(rec)
        if verbose:print('LOAD',i,round(met['height_mm'],2),'grad',con.get('max_gradient'),'cross',len(met['crossing_pairs']),con.get('reason',''),flush=True)
        if not con['ok'] or met['crossing_pairs'] or met['strain']>max_strain or met['cap_edge_error_mm']>.1:
            return dict(passed=False,reason=con.get('reason','intersection or excessive strain'),progress=i/(steps-1),records=records,spec=spec,elapsed=time.time()-start)
        last_h=h
    rd,release=m.relax(d,hold_h=False,maxiter=350,gtol=1e-8);release.update(m.metrics(rd))
    if release['ok']:
        release['min_hessian_eigenvalue']=float(np.linalg.eigvalsh(m.objective(rd,True)[2])[0])
    opened,open_state=m.relax(m.d0,hold_h=False,maxiter=350,gtol=1e-8);open_state.update(m.metrics(opened))
    if open_state['ok']:open_state['min_hessian_eigenvalue']=float(np.linalg.eigvalsh(m.objective(opened,True)[2])[0])
    passed=release['ok'] and not release['crossing_pairs'] and release['height_mm']<.45*spec['ideal_extended_height_mm'] and release['strain']<max_strain and release.get('min_hessian_eigenvalue',-1)>1e-8
    passed=passed and open_state['ok'] and not open_state['crossing_pairs'] and open_state.get('min_hessian_eigenvalue',-1)>1e-8 and open_state['height_mm']>.8*spec['ideal_extended_height_mm']
    return dict(passed=bool(passed),reason='candidate passed base screen' if passed else 'release did not pass',progress=1.,records=records,released=release,
       open_state=open_state,audited_segments=m.audited_segments,kbend=kbend,crease_ratio=ratio,thickness_offset_mm=m.dmin*m.a,barrier_activation_mm=dhat_mm,
       spec=spec,elapsed=time.time()-start,mesh=dict(faces=m.faces.tolist(),owners=m.owners.tolist(),boundary_edges=m.m['boundary_edges'],bonded_owner_pairs=m.bonded_pairs,tab_owners=m.m['tab_owners'],cap_owners=m.m['cap_owners']))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--probe',action='store_true');ap.add_argument('--lam',type=float,default=.65);ap.add_argument('--slit',type=float,default=.4)
    ap.add_argument('--steps',type=int,default=16);ap.add_argument('--kbend',type=float,default=1e-4);a=ap.parse_args()
    s=specification(lam=a.lam,slit=a.slit)
    if a.probe:
        m=ContactModel(s,kbend=a.kbend);print('objective',m.objective(m.d0)[0]);print('metrics',{k:v for k,v in m.metrics(m.d0).items() if k!='coordinates_mm'})
        d=m.d0.copy();d[-1]*=.99
        t=time.time();d,r=m.relax(d);print(r,'seconds',time.time()-t);print('crossings',m.metrics(d)['crossing_pairs'])
    else:
        r=trial(s,steps=a.steps,kbend=a.kbend,verbose=True);(OUT/'contact_probe.json').write_text(json.dumps(r));print('RESULT',r['reason'],r['elapsed'])
