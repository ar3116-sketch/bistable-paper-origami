"""Screen the rescaled one-piece body using the existing exploratory model."""
import json, time
from pathlib import Path
import numpy as np
from shapely.geometry import Polygon
from run_full_facet_search import design
from kresling_contact_search import trial
from run_kresling_search import robustness

OUT=Path(__file__).resolve().parents[1]/'output/kresling_one_piece'
OUT.mkdir(exist_ok=True)

def one_piece_spec():
    s=design(.58,43.)
    s['overlap_triangles'].pop('B')
    s.update(overlap_seams={'A':0},body_pieces=1,laminated_facet_owners=[10],page_rotation_deg=30.)
    return s

def topology(s):
    a=s['side_and_radius_mm'];u=s['flat_shift_mm'];h=s['flat_rise_mm']
    source=Polygon(s['overlap_triangles']['A'])
    received=Polygon(np.asarray(s['overlap_triangles']['A'])+[6*a,0])
    last_facet=Polygon([[5*a,0],[6*a,0],[6*a+u,h]])
    assert received.symmetric_difference(last_facet).area<1e-8
    assert s['body_pieces']==1 and s['laminated_facet_owners']==[10]
    assert not s['tabs'] and not s['tab_seams'] and not s['internal_cuts']
    t=np.deg2rad(s['page_rotation_deg']);R=np.array([[np.cos(t),-np.sin(t)],[np.sin(t),np.cos(t)]])
    outline=np.array([[-a,0],[6*a,0],[6*a+u,h],[u,h]])@R.T
    bounds=np.ptp(outline,axis=0)
    assert bounds[0]<266.7 and bounds[1]<203.2
    return dict(passed=True,body_pieces=1,full_triangle_joins=1,internal_cuts=0,
                overlap_area_mm2=source.area,page_outline_width_mm=float(bounds[0]),
                page_outline_height_mm=float(bounds[1]),laminate_owners=[10])

if __name__=='__main__':
    start=time.time();s=one_piece_spec();check=topology(s)
    (OUT/'candidate_specification.json').write_text(json.dumps(s,indent=2))
    (OUT/'topology_checks.json').write_text(json.dumps(check,indent=2))
    print('ONE PIECE',check,flush=True)
    result=trial(s,steps=64,compressed_fraction=.25,audit_steps=True,verbose=True)
    result.update(topology_check=check,compressed_fraction=.25)
    (OUT/'body_model.json').write_text(json.dumps(result))
    if result['passed']:
        print('RECOVERY',flush=True)
        result['recovery_validation']=robustness(result)
        (OUT/'body_model.json').write_text(json.dumps(result))
    print(json.dumps(dict(loading_passed=result['passed'],reason=result['reason'],
        recovery_passed=result.get('recovery_validation',{}).get('passed'),elapsed_seconds=time.time()-start)),flush=True)
