"""Adaptive Kresling search with loading, release and recovery checks."""
from pathlib import Path
import json,time,argparse,traceback
import numpy as np
from scipy.stats import qmc
from kresling_contact_search import specification,trial,ContactModel,OUT
from contact_validation import all_intersections

BOUNDS=np.array([[.56,.72],[.20,.50],[4.0,6.0],[.60,.72],[.8,1.6],[.4,.8]])
NAMES=['lambda','relief_fraction','tab_width_mm','upper_tab_centre','slot_width_mm','seam_gap_mm']

def from_vector(v):return specification(lam=v[0],slit=v[1],width=v[2],tab_centre=v[3],slot_width=v[4],seam_gap=v[5])

def robustness(result):
    """Release perturbations and reopening use identical material assumptions."""
    m=ContactModel(result['spec'],audit_steps=True,kbend=result.get('kbend',1e-4),ratio=result.get('crease_ratio',100),
                   thickness_mm=result.get('thickness_offset_mm'),dhat_mm=result.get('barrier_activation_mm',.5));scale=m.a
    def dofs(coords):
        x=np.asarray(coords)/scale
        return np.r_[x[6:11,:2].ravel(),x[m.free].ravel(),np.mean(x[6:12,2])]
    closed=dofs(result['released']['coordinates_mm']);opened=dofs(result['open_state']['coordinates_mm'])
    tests=[];rng=np.random.default_rng(1937)
    for name,base in [('closed',closed),('open',opened)]:
        for k in range(2):

            perturb=rng.normal(size=len(base));perturb/=np.linalg.norm(perturb)
            seed=base+perturb*.002
            import ipctk as ipc
            alpha=ipc.compute_collision_free_stepsize(m.cm,m.coords(base),m.coords(seed),m.dmin)
            seed=base+(seed-base)*min(1.,.8*alpha)
            d,rec=m.relax(seed,hold_h=False,maxiter=350,gtol=1e-8)
            met=m.metrics(d);rec.update(state=name,trial=k,height_mm=met['height_mm'],crossings=len(met['crossing_pairs']),displacement_from_equilibrium_mm=float(np.max(np.linalg.norm(m.coords(d)-m.coords(base),axis=1)))*scale)
            rec['pass']=bool(rec['ok'] and not met['crossing_pairs'] and rec['displacement_from_equilibrium_mm']<.15)
            tests.append(rec)

    d=closed.copy();unloading=[]
    for h in np.linspace(d[-1],opened[-1],40)[1:]:
        old=d.copy();previous=d[-1];d[-1]=h
        for j in range(len(m.free)):d[10+3*j+2]*=h/previous
        import ipctk as ipc
        if ipc.compute_collision_free_stepsize(m.cm,m.coords(old),m.coords(d),m.dmin)<1:
            return dict(passed=False,reason='reopening loading move blocked',perturbations=tests,unloading=unloading)
        for f in [.25,.5,.75,1.]:
            if all_intersections(m.coords(old+f*(d-old))*scale,m.faces,m.owners,bonded_pairs=m.bonded_pairs):
                return dict(passed=False,reason='reopening interpolation crossing',perturbations=tests,unloading=unloading)
        d,rec=m.relax(d);rec.update(m.metrics(d));unloading.append(rec)
        if not rec['ok'] or rec['crossing_pairs'] or rec['strain']>.01:
            return dict(passed=False,reason='reopening failed',perturbations=tests,unloading=unloading)
    d,rec=m.relax(d,hold_h=False,maxiter=350,gtol=1e-8);rec.update(m.metrics(d))
    recovery=rec['ok'] and not rec['crossing_pairs'] and abs(rec['height_mm']-result['open_state']['height_mm'])<.15
    return dict(passed=bool(all(x['pass'] for x in tests) and recovery),perturbations=tests,unloading=unloading,return_release=rec,
                audited_segments=m.audited_segments)

def run(budget):
    rng=np.random.default_rng(20260920);samples=qmc.scale(qmc.LatinHypercube(6,seed=20260920).random(8),BOUNDS[:,0],BOUNDS[:,1])
    # Start with the baseline and Latin-hypercube samples; then mutate the best candidate.

    proposals=[np.array([.7,.3,5.5,.7,0.,0.])]+list(samples)
    history=[];best=None;bestscore=-np.inf;start=time.time();winner=None
    for i in range(budget):
        if i<len(proposals):v=proposals[i]
        elif best is not None and rng.random()<.75:
            sigma=.12*(BOUNDS[:,1]-BOUNDS[:,0]);v=np.clip(best+rng.normal(size=6)*sigma,BOUNDS[:,0],BOUNDS[:,1])
        else:v=rng.uniform(BOUNDS[:,0],BOUNDS[:,1])
        v=np.round(v,3);row=dict(id=i,parameters=dict(zip(NAMES,map(float,v))))
        print('CANDIDATE',i,row['parameters'],flush=True)
        try:
            s=from_vector(v);r=trial(s,steps=20);score=r['progress']+(2 if r['passed'] else 0)
            row.update(passed_coarse=r['passed'],reason=r['reason'],progress=r['progress'],elapsed=r['elapsed'])
            (OUT/f'candidate_{i:03d}_coarse.json').write_text(json.dumps(r))
            if score>bestscore:bestscore=score;best=v.copy()
            if r['passed']:
                print('REFINING',i,flush=True)
                fine=trial(s,steps=64,audit_steps=True)
                (OUT/f'candidate_{i:03d}_fine.json').write_text(json.dumps(fine))
                row['passed_fine']=fine['passed'];row['fine_reason']=fine['reason']
                if fine['passed']:
                    robust=robustness(fine);fine['recovery_validation']=robust
                    (OUT/f'candidate_{i:03d}_fine.json').write_text(json.dumps(fine))
                    row['passed_recovery']=robust['passed']
                    if robust['passed']:
                        winner=fine;winner['candidate_id']=i
                        (OUT/'best_candidate.json').write_text(json.dumps(winner));row['reason']='passed numerical feasibility, release stability and reopening checks'
        except (ValueError,AssertionError,RuntimeError,np.linalg.LinAlgError) as e:
            row.update(passed_coarse=False,reason=str(e),progress=0.)
            print('REJECT',type(e).__name__,str(e),flush=True)
        history.append(row)
        summary=dict(status='model_valid_candidate_found' if winner else 'searching',elapsed_seconds=time.time()-start,
            evaluated=len(history),history=history,winner_id=winner.get('candidate_id') if winner else None,
            thresholds=dict(maximum_bar_strain=.01,cap_deformation_mm=.1,release_gradient=1e-8,minimum_hessian_eigenvalue=1e-8,closed_height_fraction_maximum=.45),
            limitations=['Assumed stiffness, not fitted to user cardstock','0.2 mm frictionless contact offset, no damage or plasticity','Bonded tab and receiving facet are excluded from self-contact','Coarse triangular mesh; no spatial mesh convergence','Independent intersection audits are sampled; IPC CCD covers its eligible pairs','Numerical feasibility does not certify a physical cardstock specimen'])
        (OUT/'search_summary.json').write_text(json.dumps(summary,indent=2));print('FINISHED',i,row['reason'],flush=True)
        if winner:break
    if not winner:
        summary['status']='budget_exhausted_without_valid_candidate';(OUT/'search_summary.json').write_text(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-candidates',type=int,default=24);args=p.parse_args();r=run(args.max_candidates)
    print('SEARCH RESULT',r['status'],r['evaluated'],round(r['elapsed_seconds'],1),flush=True)
