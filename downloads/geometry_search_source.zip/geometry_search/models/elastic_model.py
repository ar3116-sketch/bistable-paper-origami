"""Bar-and-hinge elasticity; Liu and Paulino (2017), doi:10.1098/rspa.2017.0348."""
from pathlib import Path
import json, time
import numpy as np
import autograd.numpy as anp
from autograd import value_and_grad, grad
from scipy.optimize import minimize

OUT=Path(__file__).resolve().parents[1]/'output/models'
DATA=json.loads((OUT/'surface_models.json').read_text())['models']

def refine(mesh, kind):
    vertices=[np.asarray(v,float) for v in mesh['vertices']]
    weights=[{i:1.} for i in range(len(vertices))]
    triangles=[]; owners=[]; midpoints={}
    for owner,face in enumerate(mesh['faces']):
        centre=len(vertices)
        vertices.append(np.mean([vertices[i] for i in face],axis=0))
        weights.append({i:1/len(face) for i in face})
        perimeter=[]
        for i,a in enumerate(face):
            b=face[(i+1)%len(face)]
            perimeter.append(a)
            if kind=='kresling':
                edge=tuple(sorted((a,b)))
                if edge not in midpoints:
                    midpoints[edge]=len(vertices)
                    vertices.append((vertices[a]+vertices[b])/2)
                    weights.append({a:.5,b:.5})
                perimeter.append(midpoints[edge])
        for i,a in enumerate(perimeter):
            triangles.append([a,perimeter[(i+1)%len(perimeter)],centre]);owners.append(owner)
    edge_faces={}
    for t,tri in enumerate(triangles):
        for i,a in enumerate(tri):
            b=tri[(i+1)%3];c=tri[(i+2)%3]
            edge_faces.setdefault(tuple(sorted((a,b))),[]).append((t,a,b,c))
    hinges=[];types=[]
    for edge,adj in edge_faces.items():
        if len(adj)==2:
            t,a,b,c=adj[0];u,ba,aa,d=adj[1]
            assert ba==b and aa==a
            hinges.append([a,b,c,d]);types.append('bend' if owners[t]==owners[u] else 'crease')
    return np.asarray(vertices),np.asarray(triangles),np.asarray(list(edge_faces)),np.asarray(hinges),types,weights

def signed_angles(x,hinges):
    a,b,c,d=[x[hinges[:,i]] for i in range(4)]
    e=b-a
    n1=anp.cross(e,c-a);n2=anp.cross(-e,d-b)
    unit=lambda z:z/anp.sqrt(anp.sum(z*z,axis=1,keepdims=True))
    n1,n2,axis=unit(n1),unit(n2),unit(e)
    return anp.arctan2(anp.sum(anp.cross(n1,n2)*axis,axis=1),anp.sum(n1*n2,axis=1))

class Elastic:
    def __init__(self,kind,kbend=1e-3,kcrease=1e-5):
        self.kind=kind;self.scale=30 if kind=='kresling' else 20
        mesh=DATA['kresling_extended' if kind=='kresling' else 'miura_folded_90deg']
        v,self.faces,self.edges,self.hinges,self.types,self.weights=refine(mesh,kind)
        self.x0=v/self.scale
        self.l0=np.linalg.norm(self.x0[self.edges[:,1]]-self.x0[self.edges[:,0]],axis=1)
        self.hinge_l0=np.linalg.norm(self.x0[self.hinges[:,1]]-self.x0[self.hinges[:,0]],axis=1)
        self.theta0=np.asarray(signed_angles(self.x0,self.hinges))
        self.k=np.where(np.asarray(self.types)=='bend',kbend,kcrease)
        self.kbend=kbend;self.kcrease=kcrease
        if kind=='kresling':
            self.rim=np.asarray([all(i<6 for i in w) or all(i>=6 for i in w) for w in self.weights])
            self.interior=np.flatnonzero(~self.rim)
            w=np.zeros((len(v),12));select=np.zeros((len(v),len(self.interior)))
            for i in np.flatnonzero(self.rim):
                for j,z in self.weights[i].items():w[i,j]=z
            for j,i in enumerate(self.interior):select[i,j]=1
            self.rim_weights=w;self.selector=select
        else:
            # Remove six rigid-body modes; mutual anchor distances remain free.

            self.anchor_dofs=np.array([0,1,2,8*3+1,8*3+2,72*3+2])
            self.p=len(self.x0)*3

    def energy(self,x):
        diff=x[self.edges[:,1]]-x[self.edges[:,0]]
        length=anp.sqrt(anp.sum(diff*diff,axis=1))
        axial=0.5*anp.sum(self.l0*((length/self.l0)-1)**2)
        theta=signed_angles(x,self.hinges)
        delta=anp.arctan2(anp.sin(theta-self.theta0),anp.cos(theta-self.theta0))
        hinge=0.5*anp.sum(self.k*self.hinge_l0*delta**2)
        return axial+hinge

    def map_k(self,d,h=None):
        q=d[0];H=d[1] if h is None else h
        interior=anp.reshape(d[2:] if h is None else d[1:],(-1,3))
        phi=anp.arange(6)*anp.pi/3
        bottom=anp.stack((anp.cos(phi),anp.sin(phi),anp.zeros(6)),axis=1)
        top=anp.stack((anp.cos(phi+q),anp.sin(phi+q),anp.ones(6)*H),axis=1)
        return anp.dot(self.rim_weights,anp.concatenate((bottom,top)))+anp.dot(self.selector,interior)

    def k_dof(self,x,q,h=None):
        return np.r_[q,[] if h is not None else np.mean(x[6:12,2]),x[self.interior].ravel()]

    def m_map(self,held_z=None):
        fixed=list(self.anchor_dofs)
        values=list(self.x0.ravel()[fixed])
        if held_z is not None:fixed.append(40*3+2);values.append(held_z)
        fixed=np.asarray(fixed);free=np.setdiff1d(np.arange(self.p),fixed)
        order=np.empty(self.p,dtype=int);order[free]=np.arange(len(free));order[fixed]=len(free)+np.arange(len(fixed))
        def mapping(d):return anp.reshape(anp.concatenate((d,anp.array(values)))[order],(-1,3))
        return mapping,free

    def relax(self,x,q=None,h=None,held_z=None,maxiter=1800,gtol=2e-7,ftol=1e-14):
        if self.kind=='kresling':
            mapping=lambda d:self.map_k(d,h)
            initial=self.k_dof(x,q,h)
            bounds=[(0.05,2.8)]+([] if h is not None else [(0.00001,2.)])+[(None,None)]*(len(initial)-(1 if h is not None else 2))
        else:
            mapping,free=self.m_map(held_z);initial=x.ravel()[free];bounds=None
        objective=lambda d:self.energy(mapping(d))
        result=minimize(value_and_grad(objective),initial,jac=True,method='L-BFGS-B',bounds=bounds,
                        options={'maxiter':maxiter,'ftol':ftol,'gtol':gtol,'maxls':40,'maxcor':30})
        coords=np.asarray(mapping(result.x))
        record={'energy':float(result.fun),'success':bool(result.success),'message':str(result.message),
                'iterations':int(result.nit),'max_gradient':float(np.max(np.abs(result.jac))),
                'coordinates_mm':(coords*self.scale).round(8).tolist()}
        if self.kind=='kresling':
            record['twist_deg']=float(np.degrees(result.x[0]));record['height_mm']=float(np.mean(coords[6:12,2])*self.scale)
            if h is not None:

                record['reaction_force_normalized']=float(grad(lambda H:self.energy(self.map_k(result.x,H)))(h))
        else:
            record['centre_displacement_mm']=float((self.x0[40,2]-coords[40,2])*self.scale)
            if held_z is not None:
                record['reaction_force_normalized']=float(-grad(self.energy)(coords)[40,2])
        return coords,record,result,mapping

    def stability(self,result,mapping):

        g=grad(lambda d:self.energy(mapping(d)))
        d=result.x;eps=1e-5;H=np.empty((len(d),len(d)))
        for i in range(len(d)):
            delta=np.zeros_like(d);delta[i]=eps
            H[:,i]=(g(d+delta)-g(d-delta))/(2*eps)
        H=(H+H.T)/2
        vals=np.linalg.eigvalsh(H)
        return {'smallest_hessian_eigenvalue':float(vals[0]),'negative_eigenvalues_below_minus_1e_7':int(np.sum(vals< -1e-7)),
                'degrees_of_freedom':len(d),'hessian_step':eps}

def check_gradient(model):
    rng=np.random.default_rng(10)
    x=model.x0+rng.normal(0,.001,model.x0.shape)
    direction=rng.normal(size=x.shape);direction/=np.linalg.norm(direction)
    ad=float(np.sum(grad(model.energy)(x)*direction));eps=1e-6
    fd=float((model.energy(x+eps*direction)-model.energy(x-eps*direction))/(2*eps))
    assert abs(ad-fd)<1e-7,(ad,fd)
    assert abs(float(model.energy(model.x0)))<1e-20
    return {'AD_directional_derivative':ad,'finite_difference':fd,'absolute_error':abs(ad-fd)}

def run(kind):
    start=time.time();model=Elastic(kind)
    print(kind,'nodes',len(model.x0),'hinges',len(model.hinges),flush=True)
    result={'kind':kind,'model':'Exploratory bar-and-hinge, dimensionless, uncalibrated',
       'coefficients':{'axial':1,'facet_bending':model.kbend,'crease_rotation':model.kcrease},
       'length_scale_mm':model.scale,'node_count':len(model.x0),'triangles':model.faces.tolist(),
       'gradient_check':check_gradient(model),'loading':[],'unloading':[],'released':[],
       'limitations':['No measured paper/PET properties','No self-contact, thickness, plasticity or damage',
                      'No mesh convergence study','Quasi-static minimization, not transient dynamics',
                      'Finite-load states are constrained; only released states are equilibrium candidates']}
    x=model.x0.copy();q=np.radians(24)
    if kind=='kresling':values=np.linspace(np.mean(x[6:12,2]),.04,23)
    else:values=np.linspace(x[40,2],-1.1*x[40,2],23)
    for branch,sequence in [('loading',values),('unloading',values[-2::-1])]:
        for i,val in enumerate(sequence):
            kw={'q':q,'h':float(val)} if kind=='kresling' else {'held_z':float(val)}
            x,record,_,_=model.relax(x,**kw)
            if kind=='kresling':q=np.radians(record['twist_deg'])
            result[branch].append(record)
            if i%5==0:print(kind,branch,i,'U',round(record['energy'],7),'grad',round(record['max_gradient'],8),flush=True)
            if branch=='loading' and i==len(sequence)-1:
                released,rec,opt,mapping=model.relax(x,q=q if kind=='kresling' else None,maxiter=6000)
                rec['seed']='fully loaded shape after removing imposed displacement'
                rec.update(model.stability(opt,mapping))
                result['released'].append(rec)
                print(kind,'release',rec['energy'],rec.get('height_mm',rec.get('centre_displacement_mm')),rec['smallest_hessian_eigenvalue'],flush=True)
    _,rec,opt,mapping=model.relax(model.x0,q=np.radians(24) if kind=='kresling' else None,maxiter=100)
    rec['seed']='initial reference shape';rec.update(model.stability(opt,mapping));result['released'].append(rec)
    result['elapsed_seconds']=time.time()-start
    (OUT/(kind+'_elastic_results.json')).write_text(json.dumps(result,indent=2))
    print(kind,'finished',round(time.time()-start,1),'seconds',flush=True)
    return result

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('kind',choices=['kresling','miura']);args=parser.parse_args()
    run(args.kind)
