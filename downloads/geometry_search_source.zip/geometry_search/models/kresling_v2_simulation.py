"""Triangulated Kresling geometry with rigid caps and bonded seam tabs."""
from pathlib import Path
import json, math, sys, time
import numpy as np
import autograd.numpy as anp
from scipy.spatial import Delaunay
from autograd import value_and_grad, grad
from scipy.optimize import minimize
from elastic_model import signed_angles, Elastic, check_gradient

OUT=Path(__file__).resolve().parents[1]/'output/kresling_v2'
SPEC=json.loads((OUT/'design_parameters.json').read_text())
A=SPEC['side_and_radius_mm'];S=SPEC['flat_shift_mm'];H=SPEC['flat_rise_mm']
Q0=math.radians(SPEC['ideal_twist_open_deg']);Z0=SPEC['ideal_extended_height_mm']

def mesh(spec=None):

    spec = SPEC if spec is None else spec
    A=spec['side_and_radius_mm'];S=spec['flat_shift_mm'];H=spec['flat_rise_mm']
    Q0=math.radians(spec['ideal_twist_open_deg']);Z0=spec['ideal_extended_height_mm']
    slit=spec.get('relief_cut_fraction_of_mountain',.30)
    continuous=spec.get('continuous_sheet',False)
    if continuous:
        assert slit==0 and spec.get('slot_width_mm',0)==0, 'Continuous sheet cannot have relief cuts'
    tab_seams=spec.get('tab_seams',{name:0 for name in spec['tabs']})
    seam_indices=set(tab_seams.values());seam_values={}
    for seam_index in seam_indices:
        local_tabs=[pts for name,pts in spec['tabs'].items() if tab_seams[name]==seam_index]
        values=sorted(set([0.,.5,1.]+[float(p[1]/H) for pts in local_tabs for p in [pts[0],pts[3]]]+
                             [float((pts[0][1]+pts[3][1])/(2*H)) for pts in local_tabs]))
        seam_values[seam_index]=sorted(set(round(u,10) for u in values)) if continuous else values
    phi=np.arange(6)*np.pi/3
    corners=np.r_[np.c_[A*np.cos(phi),A*np.sin(phi),np.zeros(6)],
                  np.c_[A*np.cos(phi+Q0),A*np.sin(phi+Q0),np.full(6,Z0)]]
    xyz=list(corners);registry={};flat=[];faces=[];owners=[];bindings={}
    for i in range(12):registry[('corner',i)]=i;flat.append(None)
    def add(key,coord,point=None):
        if key in registry:return registry[key]
        k=len(xyz);registry[key]=k;xyz.append(np.asarray(coord));flat.append(point);return k
    def short(i,u,lip):
        u=round(u,10)
        i%=6
        if u==0:return i
        if u==1:return i+6
        split=lip if i in seam_indices or (not continuous and abs(u-.5)<1e-9) else 'shared'
        pos=(1-u)*corners[i]+u*corners[i+6]
        gap=spec.get('seam_gap_mm',0.) if i in seam_indices and lip=='left' else (spec.get('slot_width_mm',0.)/2 if i not in seam_indices and abs(u-.5)<1e-9 else 0.)
        if gap:
            centre=np.mean(corners[[(i-1)%6,i,i+6] if lip=='left' else [i,i+6,(i+1)%6+6]],axis=0)
            along=corners[i+6]-corners[i];along/=np.linalg.norm(along)
            inward=centre-pos;inward-=np.dot(inward,along)*along
            pos+=gap*inward/np.linalg.norm(inward)
        return add(('short',i,u,split),pos)
    def mountain(i,lip):
        vals=seam_values[i%6] if i%6 in seam_indices else ([0,.25,.5,.75,1] if continuous else [0,(1-slit)/2,.5,(1+slit)/2,1])
        entries=[]
        for u in vals:
            point=np.array([i*A+S*u,H*u])
            gap=spec.get('seam_gap_mm',0.) if i%6 in seam_indices and lip=='left' and 0<u<1 else (spec.get('slot_width_mm',0.)/2 if i%6 not in seam_indices and abs(u-.5)<1e-9 else 0.)
            if gap:point+=gap*np.array([-H,S])/np.hypot(S,H)*(1 if lip=='left' else -1)
            entries.append((short(i,u,lip),point))
        return entries
    def valley(i):
        return [(i,np.array([i*A,0.])),
                (add(('valley',i),(corners[i]+corners[(i+1)%6+6])/2),np.array([i*A+(A+S)/2,H/2])),
                ((i+1)%6+6,np.array([(i+1)*A+S,H]))]
    panel_flat=[]
    for i in range(6):
        b=(i,np.array([i*A,0.]));bn=((i+1)%6,np.array([(i+1)*A,0.]));t=(i+6,np.array([i*A+S,H]));tn=((i+1)%6+6,np.array([(i+1)*A+S,H]))
        low=[b,bn]+mountain(i+1,'left')[1:]+valley(i)[-2:0:-1]
        high=valley(i)+[t]+mountain(i,'right')[-2:0:-1]
        for j,perim in enumerate([low,high]):
            owner=2*i+j
            tri_ref=[b,bn,tn] if j==0 else [b,tn,t]
            centre=add(('centre',owner),np.mean([corners[k] for k,p in tri_ref],axis=0),np.mean([p for k,p in tri_ref],axis=0))
            for k,(v,p) in enumerate(perim):
                w,q=perim[(k+1)%len(perim)]
                faces.append([v,w,centre]);owners.append(owner)
                panel_flat.append((len(faces)-1,np.array([p,q,flat[centre]])))
    body_faces=len(faces)

    bonded_owner_pairs=[];tab_owners=[]
    for tab_number,(name,pts) in enumerate(spec['tabs'].items()):
        seam_index=tab_seams[name];previous=(seam_index-1)%6;receiver_owner=2*previous
        tab_owner=12+tab_number;tab_owners.append(tab_owner);bonded_owner_pairs.append((tab_owner,receiver_owner))
        target_shift=np.array([6*A if seam_index==0 else 0.,0.])
        pts=np.asarray(pts);u0=pts[0,1]/H;u1=pts[3,1]/H
        um=(u0+u1)/2
        root_ids=[short(seam_index,u0,'right'),short(seam_index,um,'right'),short(seam_index,u1,'right')]
        p2=[pts[0],np.array([seam_index*A+S*um,H*um]),pts[3],pts[2],pts[1]]
        ids=[root_ids[0],root_ids[1],root_ids[2]]
        extra=[u for u in seam_values[seam_index] if u0+1e-9<u<u1-1e-9 and abs(u-um)>1e-9]
        if extra:
            # Match all tab-root nodes to the body mesh.

            root_values=sorted([u0,um,u1]+extra)
            ids=[short(seam_index,u,'right') for u in root_values]
            p2=[np.array([seam_index*A+S*u,H*u]) for u in root_values]+[pts[2],pts[1]]
        ref2=np.array([[previous*A,0],[(previous+1)*A,0],[(previous+1)*A+S,H]])
        ref3=corners[[previous,seam_index,seam_index+6]]
        def bary(p,tri):return np.linalg.solve(np.vstack([tri.T,np.ones(3)]),np.r_[p,1.])
        for j,p in enumerate([pts[2],pts[1]]):
            weights=bary(p+target_shift,ref2)
            ids.append(add(('tabcorner',name,j),weights@ref3,p))

        from shapely.geometry import Polygon
        inset=Polygon(pts).buffer(-1.,join_style=2)
        cent=np.array(inset.centroid.coords[0]);vs=np.array(inset.exterior.coords)[:-1]
        glue=[cent+.6*(vs[j]-cent) for j in [0,1,2]]
        for j,p in enumerate(glue):
            target=p+target_shift;found=None
            for f,tri in panel_flat:
                if owners[f]!=receiver_owner:continue
                w=bary(target,tri)
                if min(w)>-1e-9:found=(faces[f],w);break
            assert found is not None
            vs3,w=found;k=add(('glue',name,j),w@np.asarray(xyz)[vs3],p)
            bindings[k]=(vs3,w);ids.append(k);p2.append(p)
        points=np.array(p2)
        for triangle in Delaunay(points).simplices:

            a,b,c=points[triangle]
            if continuous and abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))<1e-10:
                # Omit collinear tab-root triangles emitted by Qhull.

                continue
            if (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])<0:triangle=triangle[[0,2,1]]
            faces.append([ids[j] for j in triangle]);owners.append(tab_owner)

    for end in [0,1]:
        indices=list(range(end*6,end*6+6))
        k=add(('cap',end),np.mean(corners[indices],axis=0))
        bindings[k]=(indices,np.full(6,1/6))
        for i in range(6):
            a=end*6+i;b=end*6+(i+1)%6
            faces.append([b,a,k] if end==0 else [a,b,k]);owners.append(12+len(tab_owners)+end)
    adjacent={}
    for f,tri in enumerate(faces):
        for i,a in enumerate(tri):
            b=tri[(i+1)%3];c=tri[(i+2)%3]
            adjacent.setdefault(tuple(sorted([a,b])),[]).append((f,a,b,c))
    hinges=[];types=[]
    for e,pair in adjacent.items():
        assert len(pair)<=2
        if len(pair)==2:
            f,a,b,c=pair[0];g,bb,aa,d=pair[1]
            assert a==aa and b==bb,(pair,owners[f],owners[g])
            hinges.append([a,b,c,d]);types.append('bend' if owners[f]==owners[g] else 'crease')

    free=[i for i in range(12,len(xyz)) if i not in bindings]
    transform=np.zeros((len(xyz),12+len(free)))
    transform[:12,:12]=np.eye(12)
    for j,i in enumerate(free):transform[i,12+j]=1
    for i,(source,w) in bindings.items():transform[i]=w@transform[source]
    return dict(vertices=np.array(xyz)/A,faces=np.array(faces),edges=np.array(list(adjacent)),hinges=np.array(hinges),types=types,
                transform=transform,free=free,owners=owners,body_faces=body_faces,
                tab_glue_nodes=list(bindings)[:-2],boundary_edges=[e for e,v in adjacent.items() if len(v)==1],registry=registry,
                bonded_owner_pairs=bonded_owner_pairs,tab_owners=tab_owners,cap_owners=[12+len(tab_owners),13+len(tab_owners)])

class Revised(Elastic):
    def __init__(self,kcrease=1e-5,kbend=1e-3):
        self.kind='kresling';self.scale=A
        self.mesh=mesh();m=self.mesh
        self.x0=m['vertices'];self.faces=m['faces'];self.edges=m['edges'];self.hinges=m['hinges'];self.types=m['types']
        self.interior=np.array(m['free']);self.transform=m['transform']
        self.l0=np.linalg.norm(self.x0[self.edges[:,1]]-self.x0[self.edges[:,0]],axis=1)
        self.hinge_l0=np.linalg.norm(self.x0[self.hinges[:,1]]-self.x0[self.hinges[:,0]],axis=1)
        self.theta0=np.asarray(signed_angles(self.x0,self.hinges))
        self.k=np.where(np.array(self.types)=='bend',kbend,kcrease)
        self.kbend=kbend;self.kcrease=kcrease
        assert np.max(np.abs(self.theta0[np.array(self.types)=='bend']))<1e-7
    def map_k(self,d,h=None):
        q=d[0];z=d[1] if h is None else h
        free=anp.reshape(d[2:] if h is None else d[1:],(-1,3))
        phi=anp.arange(6)*anp.pi/3
        bottom=anp.stack((anp.cos(phi),anp.sin(phi),anp.zeros(6)),axis=1)
        top=anp.stack((anp.cos(phi+q),anp.sin(phi+q),anp.ones(6)*z),axis=1)
        return anp.dot(self.transform,anp.concatenate([bottom,top,free]))

def run(ratio,kbend=1e-5,branch=0):
    model=Revised(kcrease=kbend/ratio,kbend=kbend)
    suffix=f'_branch{branch}' if branch else ''
    check=check_gradient(model)
    x=model.x0.copy();q=Q0;records=[];t=time.time()
    for i,h in enumerate(np.linspace(Z0/A,.045,41)):

        previous_h=float(np.mean(x[6:12,2]))
        q_predict=math.acos(np.clip(1-((SPEC['valley_mm']/A)**2-h*h)/2,-1,1))-math.pi/3
        dq=q_predict-q;f=x[:,2]/previous_h
        ca=np.cos(dq*f);sa=np.sin(dq*f)
        x=np.c_[ca*x[:,0]-sa*x[:,1],sa*x[:,0]+ca*x[:,1],x[:,2]*h/previous_h]
        if branch and i:
            for key,j in model.mesh['registry'].items():
                sign=0
                if key[0]=='centre':sign=1 if key[1]%2==0 else -1
                if key[0]=='short' and key[-1] in ['left','right']:sign=1 if key[-1]=='left' else -1
                if sign:
                    radial=np.r_[x[j,:2]/np.linalg.norm(x[j,:2]),0.]
                    x[j]+=branch*sign*.005*radial
        q=q_predict
        x,rec,res,mapping=model.relax(x,q=q,h=float(h),maxiter=4500,gtol=2e-7,ftol=1e-16)
        q=float(res.x[0]);rec['max_bar_strain']=float(np.max(np.abs(np.linalg.norm(x[model.edges[:,1]]-x[model.edges[:,0]],axis=1)/model.l0-1)))
        records.append(rec)
        print(ratio,i,round(rec['height_mm'],3),rec['success'],f"grad {rec['max_gradient']:.2g}",flush=True)
        if rec['max_gradient']>2e-6:
            (OUT/f'elastic_v2_ratio_{ratio}{suffix}_incomplete.json').write_text(json.dumps(records))
            raise RuntimeError('Loading residual unacceptable; stopped instead of interpreting an unconverged path.')
    x,release,res,mapping=model.relax(x,q=q,maxiter=12000,gtol=1e-9,ftol=1e-17)
    release.update(model.stability(res,mapping))
    release['max_bar_strain']=float(np.max(np.abs(np.linalg.norm(x[model.edges[:,1]]-x[model.edges[:,0]],axis=1)/model.l0-1)))
    result={'facet_to_crease_ratio':ratio,'kbend':model.kbend,'kcrease':model.kcrease,'gradient_check':check,
      'mesh':{'vertices_mm':(model.x0*A).tolist(),'faces':model.faces.tolist(),'owners':model.mesh['owners'],'edges':model.edges.tolist(),
              'boundary_edges':model.mesh['boundary_edges'],'node_count':len(x),'hinge_count':len(model.hinges),'free_dofs':len(res.x),
              'tab_glue_nodes':model.mesh['tab_glue_nodes']},
      'loading':records,'released':release,'elapsed_seconds':time.time()-t,
      'assumptions':['zero thickness','rigid polygon caps','ideal no-slip ties at three points per adhesive patch','no contact forces',
                     'initial folded rest angles','dimensionless assumed stiffness','no yielding or fracture']}
    (OUT/f'elastic_v2_ratio_{ratio}{suffix}.json').write_text(json.dumps(result))
    print('RELEASE',ratio,{k:v for k,v in release.items() if k!='coordinates_mm'},flush=True)
    return result

if __name__=='__main__':
    if '--mesh' in sys.argv:
        m=Revised();print('MESH',len(m.x0),len(m.faces),len(m.hinges),check_gradient(m))
    else:
        run(int(sys.argv[1]) if len(sys.argv)>1 else 100,float(sys.argv[2]) if len(sys.argv)>2 else 1e-5,int(sys.argv[3]) if len(sys.argv)>3 else 0)
