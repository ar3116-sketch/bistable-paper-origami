"""Kresling search restricted to continuous sheets."""
from pathlib import Path
import argparse, json, time
from collections import Counter
import numpy as np
from scipy.stats import qmc
from kresling_contact_search import specification, trial, ContactModel
from kresling_v2_simulation import mesh
from run_kresling_search import robustness

OUT=Path(__file__).resolve().parents[1]/'output/kresling_no_holes'
OUT.mkdir(exist_ok=True)
BOUNDS=np.array([[.53,.72],[4.,6.],[.60,.71],[.4,.8]])
NAMES=['lambda','tab_width_mm','upper_tab_centre','outer_seam_trim_mm']

def no_holes_spec(v):
    s=specification(lam=v[0],width=v[1],tab_centre=v[2],slit=0.,slot_width=0.,seam_gap=v[3] if len(v)>3 else .6)
    s['continuous_sheet']=True
    return s

def check_topology(s):
    m=mesh(s);counts=Counter(tuple(sorted((int(t[j]),int(t[(j+1)%3])))) for t in m['faces'] for j in range(3))
    interior=[]
    for i in range(1,6):
        ids=[i]+[m['registry'][('short',i,u,'shared')] for u in [.25,.5,.75]]+[i+6]
        for a,b in zip(ids[:-1],ids[1:]):
            assert counts[tuple(sorted((a,b)))]==2, 'An internal mountain edge is unjoined'
            interior.append([a,b])
    assert all(key[-1]=='shared' for key in m['registry'] if key[0]=='short' and key[1]!=0)
    assert min(np.linalg.norm(np.cross(m['vertices'][m['faces'][:,1]]-m['vertices'][m['faces'][:,0]],m['vertices'][m['faces'][:,2]]-m['vertices'][m['faces'][:,0]]),axis=1))>1e-10
    return dict(continuous_interior=True,internal_cut_edges=0,joined_mountain_segments=len(interior),node_count=len(m['vertices']),face_count=len(m['faces']))

def run(budget):
    start=time.time();rng=np.random.default_rng(20260920)
    samples=qmc.scale(qmc.LatinHypercube(4,seed=20260920).random(6),BOUNDS[:,0],BOUNDS[:,1])
    proposals=[np.array([lam,5.,.65,.6]) for lam in [.60,.56,.65,.70]]+list(samples)
    history=[];best=None;bestscore=-1;winner=None
    for i in range(budget):
        if i<len(proposals):v=proposals[i]
        else:v=np.clip(best+rng.normal(size=4)*.15*(BOUNDS[:,1]-BOUNDS[:,0]),BOUNDS[:,0],BOUNDS[:,1]) if best is not None else rng.uniform(BOUNDS[:,0],BOUNDS[:,1])
        v=np.round(v,3);row=dict(id=i,parameters=dict(zip(NAMES,map(float,v))))
        print('CANDIDATE',i,row['parameters'],flush=True)
        try:
            s=no_holes_spec(v);topology=check_topology(s)
            r=trial(s,steps=24,compressed_fraction=.25);r['topology_check']=topology;r['compressed_fraction']=.25
            (OUT/f'candidate_{i:03d}_coarse.json').write_text(json.dumps(r))
            row.update(passed_coarse=r['passed'],reason=r['reason'],progress=r['progress'],elapsed=r['elapsed'])
            if r.get('records'):row['max_sampled_bar_strain']=max(x['strain'] for x in r['records'])
            score=r['progress']+2*int(r['passed'])
            if score>bestscore:bestscore=score;best=v.copy()
            if r['passed']:
                print('REFINING',i,flush=True)
                fine=trial(s,steps=64,audit_steps=True,compressed_fraction=.25);fine['topology_check']=topology;fine['compressed_fraction']=.25
                (OUT/f'candidate_{i:03d}_fine.json').write_text(json.dumps(fine))
                row.update(passed_fine=fine['passed'],fine_reason=fine['reason'])
                if fine['passed']:
                    robust=robustness(fine);fine['recovery_validation']=robust
                    (OUT/f'candidate_{i:03d}_fine.json').write_text(json.dumps(fine));row['passed_recovery']=robust['passed']
                    if robust['passed']:
                        winner=fine;winner['candidate_id']=i
                        (OUT/'best_candidate.json').write_text(json.dumps(winner))
        except (ValueError,AssertionError,RuntimeError,np.linalg.LinAlgError) as e:
            row.update(passed_coarse=False,reason=type(e).__name__+': '+str(e),progress=0.)
        history.append(row)
        summary=dict(status='model_valid_candidate_found' if winner else 'searching',evaluated=len(history),elapsed_seconds=time.time()-start,history=history,winner_id=winner.get('candidate_id') if winner else None,
          constraints=dict(continuous_sheet=True,internal_holes=False,internal_slits=False,perforations=False,outer_edge_trim_only=True,side_mm=35.,N=6,letter_landscape=True),
          fixed_assumptions=dict(kbend=1e-4,facet_to_crease_stiffness_ratio=100,thickness_offset_mm=.2,barrier_activation_mm=.5,max_bar_strain=.01),
          limitations=['Assumed elastic stiffness, not measured cardstock','No plasticity, tearing, friction or spatial mesh convergence','Ideal adhesive ties with bonded contact exclusions','Failure of a finite search is not evidence of impossibility'])
        (OUT/'search_summary.json').write_text(json.dumps(summary,indent=2))
        print('FINISHED',i,row['reason'],'progress',row['progress'],flush=True)
        if winner:break
    if not winner:
        summary['status']='budget_exhausted_without_valid_candidate'
        (OUT/'search_summary.json').write_text(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-candidates',type=int,default=16);a=p.parse_args()
    r=run(a.max_candidates);print('RESULT',r['status'],r['evaluated'],r['elapsed_seconds'],flush=True)
