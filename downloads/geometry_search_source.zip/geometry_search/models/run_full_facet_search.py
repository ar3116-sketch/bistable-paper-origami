"""Two large triangular lap joints, with fully bonded laminate screening."""
import json,time
from pathlib import Path
import numpy as np
from shapely.geometry import Polygon
from kresling_contact_search import specification,trial,ContactModel
from kresling_v2_simulation import mesh
from run_kresling_search import robustness

OUT=Path(__file__).resolve().parents[1]/'output/kresling_full_facet'
OUT.mkdir(exist_ok=True)

def design(lam=.60,side=60.):
    s=specification(lam=lam,side=35.,slit=0.,slot_width=0.,seam_gap=0.)
    for key in ['side_and_radius_mm','flat_shift_mm','flat_rise_mm','valley_mm','mountain_mm','ideal_extended_height_mm']:
        s[key]*=side/35.
    for key in ['tab_valley_clearance_mm','tab_width_mm','tab_centre']:
        s.pop(key,None)
    S=s['flat_shift_mm'];H=s['flat_rise_mm']
    overlaps={name:[[i*side,0],[(i-1)*side,0],[i*side+S,H]] for name,i in [('A',0),('B',3)]}
    s.update(continuous_sheet=True,tabs={},tab_seams={},internal_cuts=False,
             overlap_triangles=overlaps,overlap_seams={'A':0,'B':3},body_pieces=2,
             laminated_facet_owners=[4,10],laminate_axial_multiplier=2.,laminate_bend_multiplier=8.,
             sheet_thickness_assumed_mm=.2,contact_thickness_mm=.4,adhesive_inset_mm=1.,
             seam_model='Fully bonded equivalent laminate; continuous single-ply creases',
             page_size='US Letter landscape',page_rotation_deg=20.)
    s['overlap_area_mm2']=Polygon(overlaps['A']).area
    s['adhesive_area_mm2']=Polygon(overlaps['A']).buffer(-s['adhesive_inset_mm'],join_style=2).area
    return s

def topology(s):
    m=mesh(s)
    assert not m['tab_owners'] and not m['bonded_owner_pairs']
    assert m['cap_owners']==[12,13]
    assert s['laminated_facet_owners']==[4,10]
    # Each extra triangle is exactly coincident with its receiving facet after
    # the two halves are joined. No paper protrudes across a receiver fold.
    a=s['side_and_radius_mm'];S=s['flat_shift_mm'];H=s['flat_rise_mm']
    for name,i in s['overlap_seams'].items():
        pts=np.array(s['overlap_triangles'][name]);j=(i-1)%6
        target=Polygon([[j*a,0],[(j+1)*a,0],[(j+1)*a+S,H]])
        translated=Polygon(pts+[6*a if i==0 else 0.,0.])
        assert translated.symmetric_difference(target).area<1e-8
    angle=np.radians(s['page_rotation_deg']);R=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])
    outline=np.array([[-a,0],[3*a,0],[3*a+S,H],[S,H]])@R.T
    bounds=np.ptp(outline,axis=0)
    assert bounds[0]<254 and bounds[1]<155,bounds
    return dict(no_internal_cuts=True,body_pieces=2,full_triangle_joins=2,
                overlap_area_mm2=s['overlap_area_mm2'],adhesive_area_mm2=s['adhesive_area_mm2'],
                page_outline_width_mm=float(bounds[0]),page_outline_height_mm=float(bounds[1]),
                node_count=len(m['vertices']),face_count=len(m['faces']),
                laminate_owners=s['laminated_facet_owners'],explicit_seam_flaps=False)

def run():
    start=time.time();history=[];winner=None
    for i,lam in enumerate([.60,.58,.62,.56,.64]):
        s=design(lam);check=topology(s)
        print('CANDIDATE',i,lam,check,flush=True)
        r=trial(s,steps=24,compressed_fraction=.25,verbose=True)
        r['topology_check']=check;r['compressed_fraction']=.25
        (OUT/f'candidate_{i:03d}_coarse.json').write_text(json.dumps(r))
        row=dict(id=i,lam=lam,passed_coarse=r['passed'],reason=r['reason'],progress=r['progress'])
        if r['passed']:
            print('REFINING',i,flush=True)
            fine=trial(s,steps=64,compressed_fraction=.25,audit_steps=True,verbose=True)
            fine['topology_check']=check;fine['compressed_fraction']=.25
            row.update(passed_fine=fine['passed'],fine_reason=fine['reason'])
            if fine['passed']:
                print('RECOVERY',i,flush=True)
                fine['recovery_validation']=robustness(fine)
                row['passed_recovery']=fine['recovery_validation']['passed']
                if row['passed_recovery']:
                    winner=fine;winner['candidate_id']=i
                    (OUT/'best_candidate.json').write_text(json.dumps(winner))
            (OUT/f'candidate_{i:03d}_fine.json').write_text(json.dumps(fine))
        history.append(row)
        summary=dict(status='model_candidate_found' if winner else 'searching',history=history,elapsed_seconds=time.time()-start,
            note='Equivalent perfectly bonded laminate, 2x axial and 8x facet bending stiffness. No physical paper calibration.')
        (OUT/'search_summary.json').write_text(json.dumps(summary,indent=2))
        print('DONE',row,flush=True)
        if winner:break
    if not winner:
        summary['status']='no_accepted_candidate';(OUT/'search_summary.json').write_text(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':print(run())
