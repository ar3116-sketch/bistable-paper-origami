"""Noncoplanar triangle-intersection screen with bonded-tab exclusions."""
from pathlib import Path
import json, numpy as np

def intersections(vertices,faces,owners):
    x=np.asarray(vertices);f=np.asarray(faces);o=np.asarray(owners);t=x[f]
    pairs=[]
    for i in range(len(f)):
        for j in range(i+1,len(f)):
            if o[i]==o[j]:continue
            if (o[i] in [12,13] and o[j]==10) or (o[j] in [12,13] and o[i]==10):continue
            if np.any(t[i].max(0)<t[j].min(0)-1e-8) or np.any(t[j].max(0)<t[i].min(0)-1e-8):continue
            pairs.append((i,j))
    if not pairs:return []
    pairs=np.array(pairs);a=t[pairs[:,0]];b=t[pairs[:,1]];hits=np.zeros(len(a),bool)
    for p,q in [(a,b),(b,a)]:
        e1=q[:,1]-q[:,0];e2=q[:,2]-q[:,0]
        for k in range(3):
            start=p[:,k];direction=p[:,(k+1)%3]-start
            cross=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,cross)
            ok=np.abs(det)>1e-10;inv=np.divide(1,det,out=np.zeros_like(det),where=ok)
            v0=start-q[:,0];u=inv*np.einsum('ij,ij->i',v0,cross)
            v1=np.cross(v0,e1);v=inv*np.einsum('ij,ij->i',direction,v1)
            along=inv*np.einsum('ij,ij->i',e2,v1)
            eps=1e-6
            hits|=ok&(u>eps)&(v>eps)&(u+v<1-eps)&(along>eps)&(along<1-eps)
    return pairs[hits].tolist()

if __name__=='__main__':
    import sys
    p=Path(sys.argv[1]);data=json.loads(p.read_text());m=data['mesh']
    records=[]
    for i,r in enumerate(data['loading']+[data['released']]):
        pairs=intersections(r['coordinates_mm'],m['faces'],m['owners'])
        records.append({'frame':i,'height_mm':r['height_mm'],'nonbonded_penetrating_face_pairs':pairs})
    out={'scope':__doc__,'frames':records,'frames_with_detected_penetration':sum(bool(r['nonbonded_penetrating_face_pairs']) for r in records)}
    path=p.with_name(p.stem+'_intersections.json');path.write_text(json.dumps(out,indent=2))
    print(path,out['frames_with_detected_penetration'])
