# Bistable paper origami — report source

Advaith Renjith · 23 September 2026

Compile the two-page report from this directory using:

    tectonic origami_design_study.tex

Alternatively, use a current TeX Live installation:

    latexmk -pdf origami_design_study.tex

The figures directory contains all four required project figures. Bibliographic citations are embedded in the TeX source and link directly to accessible full-text PDFs. Fonts and packages are standard TeX dependencies. Tectonic may need network access on its first run.

Project website: https://ar3116-sketch.github.io/bistable-paper-origami/
